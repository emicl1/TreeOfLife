/*
 * File name: Start.java
 * Date:      2023/02/22 16:21
 * Author:    @michaal4
 */

package cz.cvut.fel.pjv;

public class Start {

   public static void main(String[] args) throws Exception {
      Lab01 lab = new Lab01();
      lab.start(args);
   }

}
