/*
 * File name: Start.java
 * Date:      2014/09/04 12:34
 * Author:    Jan Faigl
 */

package cz.cvut.fel.pjv;

public class Start {

   public static void main(String[] args){
      Lab02 lab = new Lab02();
      lab.start(args);
   }
}
